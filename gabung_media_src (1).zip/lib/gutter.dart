import 'dart:io';
import 'dart:math';
import 'dart:ui' as ui;
import 'dart:ui';
import 'package:flutter/widgets.dart';
import 'comic.dart';
import 'models.dart';

/// Muat gambar latar dari penyimpanan (null bila gagal dibaca).
Future<ui.Image?> loadUiImage(String path) async {
  try {
    final bytes = await File(path).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final fr = await codec.getNextFrame();
    return fr.image;
  } catch (_) {
    return null;
  }
}

ui.Path _path(List<Offset> pts, [double dx = 0, double dy = 0]) {
  final p = ui.Path()..moveTo(pts.first.dx - dx, pts.first.dy - dy);
  for (var i = 1; i < pts.length; i++) {
    p.lineTo(pts[i].dx - dx, pts[i].dy - dy);
  }
  return p..close();
}

/// Lapisan "halaman": latar (warna / gambar) dengan lubang di setiap panel,
/// ditambah garis tepi panel. Dipakai untuk pratinjau DAN ekspor video.
void paintGutter(ui.Canvas c, double w, double h, List<Panel> panels, Bg bg, ui.Image? img) {
  final rect = Rect.fromLTWH(0, 0, w, h);
  c.saveLayer(rect, Paint());
  if (img != null) {
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final s = max(w / iw, h / ih);
    final dw = iw * s, dh = ih * s;
    c.drawImageRect(
      img,
      Rect.fromLTWH(0, 0, iw, ih),
      Rect.fromLTWH((w - dw) / 2, (h - dh) / 2, dw, dh),
      Paint()..filterQuality = FilterQuality.high,
    );
    if (bg.dim > 0) c.drawRect(rect, Paint()..color = Color.fromRGBO(0, 0, 0, bg.dim));
  } else {
    c.drawRect(rect, Paint()..color = Color(bg.color));
  }
  final clear = Paint()
    ..blendMode = BlendMode.clear
    ..isAntiAlias = true;
  for (final p in panels) {
    c.drawPath(_path(p.poly), clear);
  }
  c.restore();
  if (bg.border > 0) {
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(2.0, min(w, h) * bg.border)
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true
      ..color = bg.borderWhite ? const Color(0xFFFFFFFF) : const Color(0xFF000000);
    for (final p in panels) {
      c.drawPath(_path(p.poly), line);
    }
  }
}

Future<void> _savePng(ui.PictureRecorder rec, int w, int h, String out) async {
  final pic = rec.endRecording();
  final im = await pic.toImage(w, h);
  final bd = await im.toByteData(format: ui.ImageByteFormat.png);
  File(out).writeAsBytesSync(bd!.buffer.asUint8List());
  im.dispose();
  pic.dispose();
}

Future<void> renderGutterPng(int w, int h, List<Panel> panels, Bg bg, ui.Image? img, String out) async {
  final rec = ui.PictureRecorder();
  final c = ui.Canvas(rec);
  paintGutter(c, w.toDouble(), h.toDouble(), panels, bg, img);
  await _savePng(rec, w, h, out);
}

/// Masker hitam-putih seukuran sel panel (putih = bagian panel).
Future<void> renderMaskPng(Panel p, String out) async {
  final r = p.cell;
  final rec = ui.PictureRecorder();
  final c = ui.Canvas(rec);
  c.drawRect(Rect.fromLTWH(0, 0, r.w.toDouble(), r.h.toDouble()), Paint()..color = const Color(0xFF000000));
  c.drawPath(
    _path(p.poly, r.l.toDouble(), r.t.toDouble()),
    Paint()
      ..color = const Color(0xFFFFFFFF)
      ..isAntiAlias = true,
  );
  await _savePng(rec, r.w, r.h, out);
}

/// Pelukis pratinjau: sama persis dengan hasil ekspor.
class GutterPainter extends CustomPainter {
  final double w, h;
  final List<Panel> panels;
  final Bg bg;
  final ui.Image? img;
  GutterPainter(this.w, this.h, this.panels, this.bg, this.img);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / w);
    paintGutter(canvas, w, h, panels, bg, img);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}

/// Gambar mini bentuk susunan panel.
class LayoutThumbPainter extends CustomPainter {
  final double w, h;
  final List<Panel> panels;
  final Color color;
  LayoutThumbPainter(this.w, this.h, this.panels, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / w);
    final fill = Paint()..color = color;
    for (final p in panels) {
      canvas.drawPath(_path(p.poly), fill);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}
